import{r}from"./request-dcaba49a.js";function a(o){return r({url:"/login",method:"post",data:o})}function e(o){return r({url:"/user/changePassword",method:"post",data:o})}export{a as L,e as c};
